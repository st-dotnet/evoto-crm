import os
from flask import Flask
from flask_cors import CORS
from app.routes.auth import auth_blueprint
from app.routes.user import user_blueprint, user_profile_blueprint
from app.routes.role import roles_blueprint
from app.routes.person import lead_blueprint
from app.routes.item_category import item_category_blueprint
from app.routes.measuring_unit import measuring_unit_blueprint
from app.routes.item_image import item_image_blueprint
from app.routes.active_type import active_type_blueprint, status_list_blueprint
from app.routes.customer import customer_blueprint
from app.routes.vendor import vendor_blueprint
from app.routes.csv_import import csv_import_bp
from app.routes.item import item_blueprint
from app.routes.barcode import barcode_blueprint
from app.routes.purchase import purchase_blueprint
from app.routes.purchase_order import purchase_order_blueprint
from app.routes.quotation import quotation_blueprint
from app.routes.invoice import invoice_blueprint
from app.routes.creditIn import credit_note_blueprint
from app.routes.debit_note import debit_note_blueprint
from app.routes.purchase_invoice import purchase_invoice_blueprint
from app.routes.business_config import business_config_blueprint
from app.routes.payment_out import payment_out_blueprint
from app.routes.payment_in import payment_in_blueprint
from app.routes.share import share_blueprint
from app.routes.dashboard import dashboard_blueprint



def register_blueprints(app):
    """Register all blueprints with /api prefixes."""
    app.register_blueprint(auth_blueprint, url_prefix="/api/auth")
    app.register_blueprint(user_profile_blueprint, url_prefix="/api/user")
    app.register_blueprint(user_blueprint, url_prefix="/api/users")
    app.register_blueprint(roles_blueprint, url_prefix="/api/roles")
    app.register_blueprint(lead_blueprint, url_prefix="/api/leads")
    app.register_blueprint(item_category_blueprint, url_prefix="/api/item-categories")
    app.register_blueprint(measuring_unit_blueprint, url_prefix="/api/measuring_units")
    app.register_blueprint(item_image_blueprint, url_prefix="/api/item-images")
    app.register_blueprint(active_type_blueprint, url_prefix="/api/active-types")
    app.register_blueprint(status_list_blueprint, url_prefix="/api/status-list")
    app.register_blueprint(customer_blueprint, url_prefix="/api/customers")
    app.register_blueprint(vendor_blueprint, url_prefix="/api/vendors")
    app.register_blueprint(csv_import_bp, url_prefix="/api/csv_import")
    app.register_blueprint(item_blueprint, url_prefix="/api/items")
    app.register_blueprint(barcode_blueprint, url_prefix="/api/barcode")
    app.register_blueprint(purchase_blueprint, url_prefix="/api/purchase")
    app.register_blueprint(purchase_order_blueprint, url_prefix="/api/purchase-orders")
    app.register_blueprint(quotation_blueprint, url_prefix="/api/quotations")
    app.register_blueprint(invoice_blueprint, url_prefix="/api/invoices")
    app.register_blueprint(credit_note_blueprint, url_prefix="/api/credit-notes")
    app.register_blueprint(debit_note_blueprint, url_prefix="/api/debit-notes")
    app.register_blueprint(purchase_invoice_blueprint, url_prefix="/api/purchase-invoices")
    app.register_blueprint(payment_out_blueprint, url_prefix="/api/payment-out")
    app.register_blueprint(payment_in_blueprint, url_prefix="/api/payment-in")
    app.register_blueprint(business_config_blueprint, url_prefix="/api/business-config")
    app.register_blueprint(share_blueprint, url_prefix="/api/share-data")
    app.register_blueprint(dashboard_blueprint, url_prefix="/api/dashboard")
    # app.register_blueprint(quotation_item_blueprint, url_prefix="/api/quotation-items")


