from flask import g, request, jsonify, abort
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity, get_jwt
from app.models.user import User
import logging

logging.basicConfig(level=logging.ERROR)

def extract_jwt_info():
    """
    Middleware to verify JWT and extract user_id and business_id.
    Blocks all requests except public endpoints and OPTIONS requests.
    """
    
    # Allow CORS preflight requests
    if request.method == "OPTIONS":
        return None
    
    public_endpoints = [
        '/api/auth/signup',
        '/api/auth/login',
        '/api/auth/forgot-password',
        '/api/auth/reset-password-confirm',
        '/api/auth/verify-reset-token',
        '/api/auth/check-email',
        '/api/auth/update-password',

        # Swagger / Docs
        '/apidocs',
        '/apidocs/',
        '/apidocs/index.html',
        '/apidocs/swagger.json',

    # Flask-apispec spec endpoint (IMPORTANT)
        '/apispec_1.json',

    # Other
        '/flasgger',
        '/flasgger/',
        '/favicon.ico',
        
        # Excel Export - Public endpoint
        '/api/items/export/excel',
        
        # PDF Export - Public endpoint
        '/api/items/export/pdf',
        
        # Print PDF - Public endpoint (allow query params for browser compatibility)
        '/api/items/export/print-pdf',

        # Shared Documents - Public endpoint
        '/api/share-data/public/pdf'
    ]
    
    # Check if current endpoint is a static file or a public endpoint
    path = request.path
    if path.startswith('/static/') or path.startswith('/api/static/') or \
       path == '/static' or path == '/api/static' or \
       any(path.startswith(endpoint) for endpoint in public_endpoints):
        return None

    # Require authentication for all other endpoints
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        return jsonify({"error": "Authentication required", "message": "Missing Authorization header"}), 401

    try:
        verify_jwt_in_request()
        user_id = get_jwt_identity()
        
        # Check if the user is still active in the database
        user = User.query.filter_by(uuid=user_id).first()
        if not user or not user.isActive:
            return jsonify({
                "message": "Account deactivated or user not found. Please log in again."
            }), 403

        g.user_id = user_id
        claims = get_jwt()
        g.business_id = claims.get("business_id")
        g.role = claims.get("role")

    except Exception as e:
        logging.error(f"JWT Verification Error: {e}")
        abort(401, description="Invalid or expired token ")
