import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "mysecret")
    #SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URI", "postgresql://Sss1234!@localhost:5432/otoidb")
    #SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URI", "postgresql://evototec_tech:formless@5.189.145.124:5432/staging_evoto")
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URI", "postgresql://evoto_user:KfsL@34Dq$8d@122.160.97.61:5432/evoto_stage_db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "myjwtsecret")
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=int(os.environ.get("JWT_ACCESS_TOKEN_EXPIRES_DAYS", 1)))
    # Frontend URL for password reset links
    FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:5173")

    # Asset Storage
    # Corrected: Move UP one level from 'app' directory to reach the root static folder
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    UPLOAD_BASE_PATH = os.path.join(BASE_DIR, 'static', 'uploads')
    BUSINESS_ASSETS_FOLDER = os.path.join(UPLOAD_BASE_PATH, 'business')
    ITEM_IMAGES_FOLDER = os.path.join(BASE_DIR, 'static', 'itemImages')

    SWAGGER = {
        "title": "OTOI REST API",
        "uiversion": 3,
        "openapi": "3.0.2",
        "description": "API documentation for the OTOI REST API",
        "version": "1.0.0"
    }
    